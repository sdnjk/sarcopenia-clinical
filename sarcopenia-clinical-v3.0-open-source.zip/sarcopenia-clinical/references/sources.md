# 核心来源与核实状态

编制核查日：2026-11-06。这里的日期是核查日期，不代表以后一直为最新版本。资料分为：**V** 已读到支持该结论的正文/表格；**A** 已核实原始摘要中明确出现的内容；**B** 仅书目/目录；**P** 条款尚待核实。状态按条目判定，不因读到一部分而宣布整篇核实。以下仅简要转述，不附整篇版权全文。

## 国内主线

临床使用顺序见[人群适用性规则](population-policy.md)：中国优先，亚洲补充，国际临床来源用于对照或明确说明的缺口补充；科研方法学与研究检索不受地域限制。

| ID | 文献及永久标识 | 已核实部分 | 使用限制 |
|---|---|---|---|
| G01 | [中国肌肉减少症诊疗指南（2024版）原文 PDF](https://www.ddzxhospital.com/library/up_f/file/20250703/202507031455414992.pdf)，中华医学杂志2025;105(3):181–203 | V：问题2–7的主要诊断条款 | [中国诊断表](china-diagnosis.md)；其他条款按需查原文 |
| G07 | [老年人肌少症门诊管理规范中国专家共识（2024版）](https://rs.yiigle.com/cmaid/1526155)。中华医学会老年医学分会及期刊编辑委员会。中华老年医学杂志，2024，43(12)：1511–1517。DOI 10.3760/cma.j.issn.0254-9026.2024.12.001 | A：门诊建设与管理用途；发布于2024-12-14 | 本包门诊表单为自编工作模板，不声称逐条复制该共识规范 |
| G08 | [成人肌少症食养指南（2026年版）及附件](https://www.nhc.gov.cn/sps/c100087/202604/a69d2fce21e040dc96cbc40b923a06d3.shtml)。国家卫生健康委办公厅，2026 | V：官方通知，4月3日成文、4月23日网页发布；附件PDF可定位 | 食养、宣教来源；与临床诊疗推荐分别标识。未完整核验食谱、食养方，不直接生成其方剂或具体数值 |
| G09 | [社区老年人肌肉减少症筛查专家共识](https://www.chinagp.net/CN/10.12114/j.issn.1007-9572.2025.0150)。中国全科医学，2025，28(36)：4517–4534。DOI 10.12114/j.issn.1007-9572.2025.0150 | A：摘要明确14条推荐及GRADE方法 | 正文具体推荐待提取；不虚构全民筛查年龄或频次 |

## 亚洲和国际来源

下表是书目汇总，不代表临床优先级相同。G02/G03属于亚洲补充；G04/G05/G06属于国际临床对照或补充；R01/R02可用于全球定义与科研；S01/S02属于专病国际补充，应优先核对适用的中国专病依据。已核实程度高不能替代人群适用性。

| ID | 来源 | 已核实范围及原文定位 |
|---|---|---|
| G02 | [AWGS 2025](https://pubmed.ncbi.nlm.nih.gov/41188603/)，DOI 10.1038/s43587-025-01004-y | V：原文公开副本Table 2的握力与身高校正肌量数值 | [版本对照](china-diagnosis.md)；完整筛查路径与其他参数另查 |
| G03 | [AWGS 2019](https://pubmed.ncbi.nlm.nih.gov/32033882/?dopt=AbstractPlus)。Chen等，JAMDA，2020，21(3)：300–307.e2。DOI 10.1016/j.jamda.2019.12.012 | A：Abstract包含筛查阈值、握力、肌量与身体功能界值；使用见diagnosis。标题2019、出版2020。完整测量协议和附表需原文复核 |
| G04 | [EWGSOP2](https://pmc.ncbi.nlm.nih.gov/articles/PMC6322506/)。Cruz-Jentoft等，Age and Ageing，2019，48(1)：16–31。DOI 10.1093/ageing/afy169 | V：Table 1定义、Table 3界值、Figure 1 F-A-C-S路径及测量段。2018在线、2019卷期；适用欧洲框架，不能默认套作中国标准 |
| G05 | [ICFSR临床实践指南](https://pmc.ncbi.nlm.nih.gov/articles/PMC12280515/)，[PubMed](https://pubmed.ncbi.nlm.nih.gov/30498820/)。Dent等，J Nutr Health Aging，2018，22：1148–1161 | A：Abstract推荐抗阻活动为强推荐，蛋白补充/富蛋白饮食为条件推荐；对维生素D及合成代谢激素未给出推荐。正文入口可取得；本包未宣称核实其所有推荐编号 |
| G06 | [澳新共识指南](https://onlinelibrary.wiley.com/doi/10.1002/jcsm.13115)。Zanker等，J Cachexia Sarcopenia Muscle，2023，14：142–156。DOI 10.1002/jcsm.13115 | V：Table 3第3、9、13–16项及Discussion。2022在线、2023卷期；条款类型有EBR/CBR/PP，网页表格标记未完整显示，不能据赞同率推证据等级 |
| R01 | [GLIS概念定义](https://pmc.ncbi.nlm.nih.gov/articles/PMC10960072/)。Kirk等，Age and Ageing，2024，53：afae052。DOI 10.1093/ageing/afae052 | V：共识表及Discussion。概念共识与操作性定义不同，不提供本包可直接调用的新诊断阈值 |
| R02 | [GLIS结局共识](https://pubmed.ncbi.nlm.nih.gov/40120052/)。Beaudart等，Aging Clin Exp Res，2025，37：100。DOI 10.1007/s40520-025-02995-9 | A：Abstract。关注生活质量、跌倒、骨折、死亡等健康结局。工具、MCID和具体分级待全文核实 |
| S01 | [ESPEN/EASO肌少性肥胖共识](https://pubmed.ncbi.nlm.nih.gov/35196654/)，[全文](https://pmc.ncbi.nlm.nih.gov/articles/PMC9210010/)。Donini等，Obesity Facts，2022，15：321–335。DOI 10.1159/000521241 | A/V：摘要及诊断程序段。筛查后评估肌肉功能和身体成分；不能凭BMI加低握力确诊。专用界值未收录 |
| S02 | [KDIGO 2024 CKD指南](https://kdigo.org/wp-content/uploads/2024/03/KDIGO-2024-CKD-Guideline.pdf)，[版本入口](https://kdigo.org/guidelines/ckd-evaluation-and-management/) | V：3.3.1，Recommendation 3.3.1.1与相关Practice Points；供处理肾病营养冲突。使用时查原文及更新，特别注意老年、衰弱、肌少症的个体化说明 |

## 方法学来源

- [EQUATOR STROBE入口](https://equator-network.org/reporting-guidelines/strobe/index.html)：观察性研究报告；页面明确报告规范不等于设计或质量评价工具。
- [CONSORT 2025入口](https://equator-network.org/reporting-guidelines/consort/index.html)：随机试验报告，按需检查扩展。
- [EQUATOR规范库](https://equator-network.org/reporting-guidelines/index.html)：按研究设计核实PRISMA、STARD、TRIPOD+AI、SPIRIT、SQUIRE等的适用版本。不因列于此就声称已逐项完成审核。

## 条目级使用门槛

| 内容 | 可以使用 | 必须追加核查 |
|---|---|---|
| G03摘要明确数值 | 标记AWGS 2019的指标解释和旧版重现 | 完整诊断、测量协议、特殊年龄适用性 |
| G04表1/3 | 明确标为欧洲框架的对照或指定研究复现 | 不得作为中国患者默认标准；实际使用先完成适用性与测量核查 |
| G02定义变化 | 解释核心更新 | 数值判定、50–64岁参数及完整类别算法 |
| G06第13–16项 | 明确标为澳新来源的补充/对照信息 | 优先查中国/亚洲依据；不得作为中国患者默认剂量，追加个体适用性及原表类型核验 |
| G01 | 已核对的中国诊断条款 | 其他推荐、剂量及专病适用性 |
| G07/G09 | 来源与场景定位 | 按需核对具体推荐 |

本包不含真实患者资料，不附整篇指南PDF。正文网络读取失败、PDF过大或访问限制属于取得方式限制，不代表文献不存在，也不允许用二手解读填补原始条款。

扩展见[临床指南索引](clinical-library.md)及[科研全流程](research-lifecycle.md)。
