# 通用医学科研全流程

适用于肌少症以外的医学研究。先确定设计和阶段，再加载相关规范；报告规范、研究执行要求、偏倚评价工具及法规各有用途，不相互代替。以下是常用规范入口，按实际设计查现行版本和扩展。

| 阶段 | 应交付什么 | 权威入口与选用规则 |
|---|---|---|
| 立题与证据缺口 | PICO/PECO、临床决策、可行性和检索记录；保存库、日期、完整检索式、筛选理由 | [Cochrane Handbook](https://training.cochrane.org/handbook)、[EQUATOR](https://www.equator-network.org/reporting-guidelines/)；综述用PRISMA-P、PRISMA 2020、PRISMA-S；范围综述用PRISMA-ScR |
| 方案与预注册 | 目标人群、干预/暴露、对照、主要结局和时间点、估计目标、样本量、数据与安全计划、版本变更 | [SPIRIT 2025](https://www.bmj.com/content/389/bmj-2024-081477)；干预细节用TIDieR，运动可查CERT；[ChiCTR](https://www.chictr.org.cn/)、[WHO ICTRP](https://www.who.int/clinical-trials-registry-platform)；系统综述按资格选[PROSPERO](https://www.crd.york.ac.uk/prospero/) |
| 伦理与启动 | 审批与登记核查表、知情同意、招募公平性、风险预案、数据访问和共享权限 | [中国涉及人的研究伦理审查办法](https://www.nhc.gov.cn/qjjys/c100016/202302/6b6e447b3edc4338856c9a652a85f44b.shtml)、[中国研究者发起临床研究管理办法](https://www.nhc.gov.cn/qjjys/c100016/202409/3a3ad0a7b656420d9580b65f2321a623.shtml)、[WMA赫尔辛基宣言](https://www.wma.net/policies-post/wma-declaration-of-helsinki/)、[ICH E6(R3)](https://database.ich.org/sites/default/files/ICH_E6%28R3%29_Step4_FinalGuideline_2025_0106_ErrorCorrections_2025_1024.pdf)。按机构、项目和当地实施要求判断适用性，不能自行认定免审 |
| 实施与数据 | CRF、变量字典、数据校验规则、设备与评估者培训、招募/偏离/不良事件日志、缺失原因、锁库记录 | 适用时按ICH GCP及本地制度，先定严重事件报告流程与监查职责，不凭人数设置通用门槛；区分匿名化与编码脱敏，不将可识别数据上传外部服务 |
| 统计分析 | SAP、分析集、主要模型、效应与区间、多重性、亚组、缺失与敏感性、可复现代码 | [ICH E9(R1)统计与估计目标](https://www.ich.org/page/efficacy-guidelines)；依设计选择方法；记录软件、版本、输入、假设和可复算输出 |
| 偏倚与证据综合 | 按结局评价偏倚，解释异质性、不精确性与间接性 | [RoB 2、ROBINS-I](https://www.riskofbias.info/)、Cochrane Handbook；诊断准确性查适用QUADAS版本，预测模型查PROBAST/PROBAST+AI，综述评价查AMSTAR 2；GRADE针对证据体而非单篇 |
| 撰写与发表 | 结果表、流程图、登记与方案差异、资助与利益冲突、作者贡献、受限共享及归档计划 | [EQUATOR按设计选规范](https://www.equator-network.org/reporting-guidelines/)；[ICMJE](https://www.icmje.org/recommendations/)、[COPE](https://publicationethics.org/core-practices)、[CRediT](https://credit.niso.org/)；登记、方案、SAP、稿件与分析代码保留版本 |

## 按设计选择报告规范

- 随机试验：[CONSORT 2025](https://www.bmj.com/content/389/bmj-2024-081123)，匹配整群、交叉、非劣效、可行性、非药物及伤害扩展；方案用SPIRIT。
- 观察性研究：STROBE；常规收集数据加RECORD。明确时间零点、比较策略、测量偏倚、混杂及适用分母。
- 诊断：STARD或适用扩展；明确待测与参考标准、盲法、未验证者处理。预测：TRIPOD+AI；区分开发、内部验证、外部验证、校准、判别及临床效用。
- 系统综述：PRISMA系列按问题匹配；质性：COREQ/SRQR；个案：CARE；质量改进：SQUIRE；经济学：CHEERS；动物：ARRIVE；临床指南：RIGHT、AGREE II。按EQUATOR核查所需版本及原始清单。

## 上轮错误的交付门槛

1. 同一页对齐**题目、纳入条件、主要结局及时间点、主模型、样本量**。筛查阳性研究不可写成确诊患者治疗试验；要估计指导本身，说明接触时间、共干预和污染。否则明确定义为“整个指导策略”的效果。
2. ITT按随机组别，不能要求接受至少一次干预或完成测量才算ITT。区分目标分析人群、实际有观测者和缺失处理；不可用固定缺失百分比决定插补。
3. 无可靠效应量、变异或事件率时默认不给推荐样本数。仅按要求演算假设情景，并注明主模型、差值、SD种类、双侧α、把握度、组比、聚类与失访；计算结果须可复算。先对未膨胀基数核对，再仅膨胀一次并向上取整。预实验主要检验可行性及估计变异，不把小样本效应点估计当可靠疗效。
4. 不编造伦理要求、注册号、批准状态、结果或文献参数。统计结果区分计划和实际；新增探索结果须标明。
5. 默认约1–2页：决策/方案摘要、关键依据、未决事项。收到“完整方案/SAP/投稿清单”再展开。末尾列出最可能改变结论的1–3个问题。

电子病历观察性研究追加读取[ehr-cohort](ehr-cohort.md)，不能套用SPIRIT；执行与引用边界见[runtime-contract](runtime-contract.md)。
