"""Validate a deployed skill's file integrity. Not a clinical validation."""
from pathlib import Path
import hashlib
import json
import re
import sys

root = Path(__file__).resolve().parents[1]
errors = []
manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
for name, expected in manifest['files'].items():
    p = root / name
    if not p.is_file():
        errors.append('MISSING: ' + name)
    elif hashlib.sha256(p.read_bytes()).hexdigest() != expected:
        errors.append('CHANGED: ' + name)
for p in root.rglob('*.md'):
    for link in re.findall(r'\]\(([^)]+)\)', p.read_text(encoding='utf-8')):
        if '://' not in link and not link.startswith('#'):
            if not (p.parent / link.split('#')[0]).is_file():
                errors.append('BROKEN LINK: ' + str(p.relative_to(root)) + ': ' + link)
print(json.dumps({'version': manifest['version'], 'checked': len(manifest['files']), 'errors': errors}, ensure_ascii=False))
sys.exit(bool(errors))
